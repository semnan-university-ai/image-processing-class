function list= loadIM()
image1=imread('train/1.jpg');
image2=imread('train/2.jpg');
image3=imread('train/3.jpg');
image4=imread('train/4.jpg');
image5=imread('train/5.jpg');
image6=imread('train/1-2.jpg');
image7=imread('train/2-2.jpg');
image8=imread('train/3-2.jpg');
image9=imread('train/4-2.jpg');
image10=imread('train/5-2.jpg');
image11=imread('train/image (55).jpg');
image12=imread('train/image (56).jpg');
image13=imread('train/image (86).jpg');
image14=imread('train/image (90).jpg');
image15=imread('train/narenji.jpg');
image16=imread('train/sabz.jpg');
image17=imread('train/abi.jpg');

pansad=fitness(image1); %1
Bpansad=fitness(image6);%2
NBpansad=fitness(image14);%14
hezar=fitness(image2);%3
Bhezar=fitness(image7);%4
Nhezar=fitness(image12);%5
NBhezar=fitness(image11);%6
dohezar=fitness(image3);%7
Bdohezar=fitness(image8);%8
panjhezar=fitness(image4);%9
Bpanjhezar=fitness(image13);%10
NBpanjhezar=fitness(image9);%11
dahhezar=fitness(image5);%12
Bdahhezar=fitness(image10);%13
narenji=fitness(image15);%15    
sabz=fitness(image16);%16
abi=fitness(image17);%17

list={pansad ,Bpansad,hezar,Bhezar,Nhezar,NBhezar,dohezar,Bdohezar,panjhezar,Bpanjhezar,NBpanjhezar,dahhezar,Bdahhezar,NBpansad,narenji,sabz,abi};


end