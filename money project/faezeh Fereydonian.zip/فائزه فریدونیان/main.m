clc
clear 
close all

Timage=imread('money-dataset/image (63).jpg');
% imshow(Timage);
list=loadIM();
dif={};

% Timage=crop_background(Timage);

test=fitness(Timage);

Tmax=maximum(test);
Tmin=minimum(test);
difference=test{Tmax} - test{Tmin};

result={};
z={};
count=0;
for j=1:length(list)
    R=list{1,j};
    for i=1:40
        if R{i}==test{i} || R{i}-10< test{i} && test{i}<R{i}+10
            z{i}=1;
           count=count+1;
        else
            z{i}=0;
        end
       
    end
    result{j}=count;
    count=0;
end
top=maximum(result);

if difference < 30
    top=15;
end
switch top
    case top==1
        disp('500 toman');
    
    case 2
        disp('500 toman');
        
    case 3
         disp('1000 toman');
    case 4
         disp('1000 toman');
    case 5
         disp('1000 toman');
    case 6
         disp('1000 toman');
    case 7
         disp('2000 toman');
    case 8
         disp('2000 toman'); 
    case 9
         disp('5000 toman');  
    case 10
         disp('5000 toman'); 
    case 11
         disp('5000 toman');
    case 12
         disp('10000 toman');
    case 13
         disp('10000 toman');
    case 14
         disp('500 toman');  
    case 15
         disp('in faghat ye tike kagaze');      
  
end