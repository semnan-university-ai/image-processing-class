function top=maximum(result)

max=result{1};
topp=1;
for i=2:length(result)
    if result{i}> max
        max=result{i};
        topp=i; 
    end
end
top=topp;

end