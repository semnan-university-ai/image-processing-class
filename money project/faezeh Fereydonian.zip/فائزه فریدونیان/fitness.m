function  x= fitness(pic)
% a=imshow(pic);
 [height ,width ,k] = size(pic);
if height > width    % if is it portraint ,rotate to landscape
        pic =imrotate(pic,90);
end
image=imresize(pic,[150,320]);
Rimage=image(:,:,1);
Rimage=medfilt2(Rimage);
imshow(Rimage);

a={};
m=1;
n=8;
for i=1:40
    a{i}=mean(mean(Rimage(1:150 , m:n)));
    m=n;
    n=n+8;
end

x=a;
end