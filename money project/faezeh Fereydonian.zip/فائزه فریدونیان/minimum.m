function low=minimum(result)
min=result{1};
a=1;
for i=2:length(result)
    if result{i}< min
        min=result{i};
        a=i; 
    end
end
low=a;

end
