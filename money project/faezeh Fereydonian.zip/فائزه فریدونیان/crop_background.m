 function image = crop_background(img)

  imgGray=rgb2gray(img);
  % find edges
  edges=edge(imgGray,'canny',0.5);
  binaryImage = bwareafilt(edges, 1);
  [rows, columns] = find(binaryImage);
  row1 = min(rows);
  row2 = max(rows);
  col1 = min(columns);
  col2 = max(columns);
%Crop
if row2-row1 >70 && col2-col1 > 180
    croppedImage = img(row1:row2, col1:col2, :);
      croppedImage=imresize(croppedImage,[150,300]);  
%      figure;imshow(croppedImage);
       image=croppedImage;
else
%      figure;imshow(img);
      image =img; 
       
end

