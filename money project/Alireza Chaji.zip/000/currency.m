function  f=as(deg);

if deg>91
    f=1000;
  elseif (71<deg) & (deg<72)
    f=2000; 
  elseif (65<deg) & (deg<66)
    f=5000; 
else  
    f=1000; 
end




