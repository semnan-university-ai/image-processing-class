function [centx,centy,r]=as(L);

[w h]=size(L');

mx=max(max(L));
r=mx;
for i=1:h
    for j=1:w
        if L(i,j)==mx;
            centx=j;
            centy=i;
        end
    end
end
      
