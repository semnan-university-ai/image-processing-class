function  f=as(deg);

if deg>58
    f=10000;
  elseif (71<deg) & (deg<72)
    f=2000; 
  else  
    f=1000; 
end




