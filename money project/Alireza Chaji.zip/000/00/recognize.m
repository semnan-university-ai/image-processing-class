close all; 
clear all; 
clc;

file = input('please enter the image file name:','s');  

I = imread(file);
flg=isrgb(I);             %

if flg==1
    I=rgb2gray(I);
end

[h,w]=size(I);
figure;imshow(I);

c = edge(I, 'canny',0.3);  % 
figure; imshow(c);         % 

se = strel('dis',2);      %
I2 = imdilate(c,se);       % 
imshow(I2);                %

d2 = imfill(I2, 'holes');  % 
figure, imshow(d2);        %

Label=bwlabel(d2,4);

a1=(Label==1);


L1 = bwdist(~a1);           % 
figure, imshow(L1,[]),      %  
[xc1 yc1 r1]=as(L1);
f1=1*currency(r1)


