close all; 
clear all; 
clc;

file = input('please enter the image file name:','s');  

I = imread(file);
flg=isrgb(I);             %

if flg==1
    I=rgb2gray(I);
end

[h,w]=size(I);
figure;imshow(I);

c = edge(I, 'canny',0.3);  % 
figure; imshow(c);         % 

se = strel('dis',2);      %
I2 = imdilate(c,se);       % 
imshow(I2);                %

d2 = imfill(I2, 'holes');  % 
figure, imshow(d2);        %

Label=bwlabel(d2,4);

a1=(Label==1);
a2=(Label==2);
a3=(Label==3);
a4=(Label==4);

L1 = bwdist(~a1);           % 
figure, imshow(L1,[]),      %  
[xc1 yc1 r1]=as(L1);
f1=1*currency(r1)


L2 = bwdist(~a2);           % 
figure, imshow(L2,[]),      %  
[xc2 yc2 r2]=as(L2);
f2=2*currency(r2)


L3 = bwdist(~a3);           % 
figure, imshow(L3,[]),      %  
[xc3 yc3 r3]=as(L3);
f3=5*currency(r3)

L4 = bwdist(~a4);           % 
figure, imshow(L4,[]),      %  
[xc4 yc4 r4]=as(L4);
f4=10*currency(r4)